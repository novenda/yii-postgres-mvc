<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;

/* @var $this yii\web\View */
/* @var $model app\models\Tblbarang */
/* @var $form yii\widgets\ActiveForm */
?>

<div class="tblbarang-form">

    <?php $form = ActiveForm::begin(); ?>

    <?= $form->field($model, 'barang')->textInput(['maxlength' => true]) ?>

    <div class="form-group">
        <?= Html::submitButton('Save', ['class' => 'btn btn-success']) ?>
    </div>

    <?php ActiveForm::end(); ?>

</div>
