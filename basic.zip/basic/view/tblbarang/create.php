<?php

use yii\helpers\Html;

/* @var $this yii\web\View */
/* @var $model app\models\Tblbarang */

$this->title = 'Create Tblbarang';
$this->params['breadcrumbs'][] = ['label' => 'Tblbarangs', 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="tblbarang-create">

    <h1><?= Html::encode($this->title) ?></h1>

    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>

</div>
