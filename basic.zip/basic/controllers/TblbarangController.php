<?php

namespace app\controllers;

use app\models\Tblbarang;
use app\models\TblbarangSearch;
use yii\web\Controller;
use yii\web\NotFoundHttpException;
use yii\filters\VerbFilter;

/**
 * TblbarangController implements the CRUD actions for Tblbarang model.
 */
class TblbarangController extends Controller
{
    /**
     * @inheritDoc
     */
    public function behaviors()
    {
        return array_merge(
            parent::behaviors(),
            [
                'verbs' => [
                    'class' => VerbFilter::className(),
                    'actions' => [
                        'delete' => ['POST'],
                    ],
                ],
            ]
        );
    }

    /**
     * Lists all Tblbarang models.
     *
     * @return string
     */
    public function actionIndex()
    {
        $searchModel = new TblbarangSearch();
        $dataProvider = $searchModel->search($this->request->queryParams);

        return $this->render('index', [
            'searchModel' => $searchModel,
            'dataProvider' => $dataProvider,
        ]);
    }

    /**
     * Displays a single Tblbarang model.
     * @param int $idbarang Idbarang
     * @return string
     * @throws NotFoundHttpException if the model cannot be found
     */
    public function actionView($idbarang)
    {
        return $this->render('view', [
            'model' => $this->findModel($idbarang),
        ]);
    }

    /**
     * Creates a new Tblbarang model.
     * If creation is successful, the browser will be redirected to the 'view' page.
     * @return string|\yii\web\Response
     */
    public function actionCreate()
    {
        $model = new Tblbarang();

        if ($this->request->isPost) {
            if ($model->load($this->request->post()) && $model->save()) {
                return $this->redirect(['view', 'idbarang' => $model->idbarang]);
            }
        } else {
            $model->loadDefaultValues();
        }

        return $this->render('create', [
            'model' => $model,
        ]);
    }

    /**
     * Updates an existing Tblbarang model.
     * If update is successful, the browser will be redirected to the 'view' page.
     * @param int $idbarang Idbarang
     * @return string|\yii\web\Response
     * @throws NotFoundHttpException if the model cannot be found
     */
    public function actionUpdate($idbarang)
    {
        $model = $this->findModel($idbarang);

        if ($this->request->isPost && $model->load($this->request->post()) && $model->save()) {
            return $this->redirect(['view', 'idbarang' => $model->idbarang]);
        }

        return $this->render('update', [
            'model' => $model,
        ]);
    }

    /**
     * Deletes an existing Tblbarang model.
     * If deletion is successful, the browser will be redirected to the 'index' page.
     * @param int $idbarang Idbarang
     * @return \yii\web\Response
     * @throws NotFoundHttpException if the model cannot be found
     */
    public function actionDelete($idbarang)
    {
        $this->findModel($idbarang)->delete();

        return $this->redirect(['index']);
    }

    /**
     * Finds the Tblbarang model based on its primary key value.
     * If the model is not found, a 404 HTTP exception will be thrown.
     * @param int $idbarang Idbarang
     * @return Tblbarang the loaded model
     * @throws NotFoundHttpException if the model cannot be found
     */
    protected function findModel($idbarang)
    {
        if (($model = Tblbarang::findOne(['idbarang' => $idbarang])) !== null) {
            return $model;
        }

        throw new NotFoundHttpException('The requested page does not exist.');
    }
}
