<?php

use yii\db\Migration;

/**
 * Handles the creation of table `{{%tblbarang}}`.
 */
class m220627_174710_create_tblbarang_table extends Migration
{
    /**
     * {@inheritdoc}
     */
    public function safeUp()
    {
        $this->createTable('{{%tblbarang}}', [
            'idbarang' => $this->bigPrimaryKey(54),
            'barang'=> $this->char(20),
            'nobarang' => $this->string(50),
            

        ]);
    }

    /**
     * {@inheritdoc}
     */
    public function safeDown()
    {
        $this->dropTable('{{%tblbarang}}');
    }
}
