<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "tblbarang".
 *
 * @property int $idbarang
 * @property string|null $barang
 * @property string|null $nobarang
 */
class Tblbarang extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'tblbarang';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['barang'], 'string', 'max' => 20],
            [['nobarang'], 'string', 'max' => 50],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'idbarang' => 'Idbarang',
            'barang' => 'Barang',
            'nobarang' => 'Nobarang',
        ];
    }
}
